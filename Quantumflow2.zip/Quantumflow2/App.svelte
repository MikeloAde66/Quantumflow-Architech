<script>
  import { onMount } from 'svelte';
  
  // State
  let assets = 'AAPL,GOOGL,MSFT,TSLA,BTC-USD';
  let riskTolerance = 0.5;
  let investmentAmount = 10000;
  let useRealData = true;
  let lookbackDays = 365;
  
  let result = null;
  let loading = false;
  let error = null;
  
  const API_URL = 'http://localhost:8000';
  
  // Optimize portfolio
  async function optimizePortfolio() {
    loading = true;
    error = null;
    result = null;
    
    try {
      const assetList = assets.split(',').map(a => a.trim().toUpperCase());
      
      const response = await fetch(`${API_URL}/optimize`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          assets: assetList,
          risk_tolerance: riskTolerance,
          investment_amount: investmentAmount,
          use_real_data: useRealData,
          lookback_days: lookbackDays
        })
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.detail || 'Optimization failed');
      }
      
      result = await response.json();
      
    } catch (err) {
      error = err.message;
      console.error('Optimization error:', err);
    } finally {
      loading = false;
    }
  }
  
  // Format currency
  function formatCurrency(value) {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(value);
  }
  
  // Format percentage
  function formatPercent(value) {
    return (value * 100).toFixed(2) + '%';
  }
  
  // Get risk label
  function getRiskLabel(risk) {
    if (risk < 0.3) return 'Conservative';
    if (risk < 0.7) return 'Balanced';
    return 'Aggressive';
  }
  
  // Health check on mount
  onMount(async () => {
    try {
      const response = await fetch(`${API_URL}/health`);
      const health = await response.json();
      console.log('🌌 QuantumFlow API Status:', health);
    } catch (err) {
      console.error('API health check failed:', err);
    }
  });
</script>

<main>
  <div class="container">
    <header>
      <h1>🌌 QuantumFlow</h1>
      <p class="subtitle">Quantum-Enhanced Portfolio Optimization</p>
    </header>
    
    <div class="card">
      <h2>Configure Portfolio</h2>
      
      <div class="form-group">
        <label for="assets">
          Assets (comma-separated tickers)
          <span class="hint">Max 12 assets</span>
        </label>
        <input
          id="assets"
          type="text"
          bind:value={assets}
          placeholder="AAPL,GOOGL,MSFT,TSLA,BTC-USD"
          disabled={loading}
        />
      </div>
      
      <div class="form-group">
        <label for="risk">
          Risk Tolerance: {formatPercent(riskTolerance)} ({getRiskLabel(riskTolerance)})
        </label>
        <input
          id="risk"
          type="range"
          min="0"
          max="1"
          step="0.01"
          bind:value={riskTolerance}
          disabled={loading}
        />
        <div class="range-labels">
          <span>Conservative</span>
          <span>Aggressive</span>
        </div>
      </div>
      
      <div class="form-group">
        <label for="amount">Investment Amount</label>
        <input
          id="amount"
          type="number"
          bind:value={investmentAmount}
          min="100"
          step="100"
          disabled={loading}
        />
      </div>
      
      <div class="form-group">
        <label class="checkbox-label">
          <input
            type="checkbox"
            bind:checked={useRealData}
            disabled={loading}
          />
          Use real market data (Yahoo Finance)
        </label>
      </div>
      
      {#if useRealData}
        <div class="form-group">
          <label for="lookback">Historical Data Period (days)</label>
          <select id="lookback" bind:value={lookbackDays} disabled={loading}>
            <option value={30}>1 Month</option>
            <option value={90}>3 Months</option>
            <option value={180}>6 Months</option>
            <option value={365}>1 Year</option>
            <option value={730}>2 Years</option>
          </select>
        </div>
      {/if}
      
      <button
        class="optimize-btn"
        on:click={optimizePortfolio}
        disabled={loading}
      >
        {#if loading}
          ⚛️ Computing Quantum State...
        {:else}
          🚀 Optimize Portfolio
        {/if}
      </button>
    </div>
    
    {#if error}
      <div class="card error-card">
        <h3>❌ Error</h3>
        <p>{error}</p>
      </div>
    {/if}
    
    {#if result}
      <div class="card results-card">
        <h2>✨ Quantum-Optimized Portfolio</h2>
        
        <div class="metrics-grid">
          <div class="metric">
            <div class="metric-label">Expected Return</div>
            <div class="metric-value">{formatPercent(result.metrics.expected_return)}</div>
          </div>
          
          <div class="metric">
            <div class="metric-label">Portfolio Risk</div>
            <div class="metric-value">{formatPercent(result.metrics.risk_score)}</div>
          </div>
          
          <div class="metric">
            <div class="metric-label">Sharpe Ratio</div>
            <div class="metric-value">{result.metrics.sharpe_ratio.toFixed(4)}</div>
          </div>
          
          <div class="metric quantum-advantage">
            <div class="metric-label">Quantum Advantage</div>
            <div class="metric-value">
              +{formatPercent(result.metrics.quantum_advantage_score)}
            </div>
          </div>
        </div>
        
        <h3>Asset Allocation</h3>
        <div class="allocations">
          {#each result.allocations as allocation}
            <div class="allocation-row">
              <div class="allocation-ticker">{allocation.ticker}</div>
              <div class="allocation-bar-container">
                <div
                  class="allocation-bar"
                  style="width: {allocation.weight * 100}%"
                ></div>
              </div>
              <div class="allocation-weight">{formatPercent(allocation.weight)}</div>
              <div class="allocation-amount">{formatCurrency(allocation.amount)}</div>
            </div>
          {/each}
        </div>
        
        <div class="execution-info">
          <p>
            <strong>Execution Time:</strong> {result.execution_time_ms}ms
            <span class="separator">•</span>
            <strong>Quantum Mode:</strong> {result.quantum_mode}
            <span class="separator">•</span>
            <strong>Convergence:</strong> {result.portfolio.convergence_iterations} iterations
          </p>
        </div>
      </div>
    {/if}
    
    <footer>
      <p>
        Powered by 12-qubit QAOA • Built with consciousness by Proto Studios
      </p>
    </footer>
  </div>
</main>

<style>
  :global(body) {
    margin: 0;
    padding: 0;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    min-height: 100vh;
  }
  
  main {
    padding: 2rem;
  }
  
  .container {
    max-width: 900px;
    margin: 0 auto;
  }
  
  header {
    text-align: center;
    color: white;
    margin-bottom: 2rem;
  }
  
  h1 {
    font-size: 3rem;
    margin: 0;
    font-weight: 700;
    text-shadow: 2px 2px 4px rgba(0,0,0,0.2);
  }
  
  .subtitle {
    font-size: 1.2rem;
    opacity: 0.9;
    margin-top: 0.5rem;
  }
  
  .card {
    background: white;
    border-radius: 12px;
    padding: 2rem;
    box-shadow: 0 10px 30px rgba(0,0,0,0.2);
    margin-bottom: 1.5rem;
  }
  
  h2 {
    margin-top: 0;
    color: #333;
    font-size: 1.5rem;
  }
  
  h3 {
    color: #555;
    font-size: 1.2rem;
    margin-top: 2rem;
    margin-bottom: 1rem;
  }
  
  .form-group {
    margin-bottom: 1.5rem;
  }
  
  label {
    display: block;
    font-weight: 600;
    margin-bottom: 0.5rem;
    color: #555;
  }
  
  .hint {
    font-size: 0.85rem;
    font-weight: normal;
    color: #888;
  }
  
  input[type="text"],
  input[type="number"],
  select {
    width: 100%;
    padding: 0.75rem;
    border: 2px solid #e0e0e0;
    border-radius: 8px;
    font-size: 1rem;
    transition: border-color 0.3s;
  }
  
  input[type="text"]:focus,
  input[type="number"]:focus,
  select:focus {
    outline: none;
    border-color: #667eea;
  }
  
  input[type="range"] {
    width: 100%;
    height: 8px;
    border-radius: 5px;
    background: #e0e0e0;
    outline: none;
  }
  
  input[type="range"]::-webkit-slider-thumb {
    appearance: none;
    width: 20px;
    height: 20px;
    border-radius: 50%;
    background: #667eea;
    cursor: pointer;
  }
  
  .range-labels {
    display: flex;
    justify-content: space-between;
    font-size: 0.85rem;
    color: #888;
    margin-top: 0.25rem;
  }
  
  .checkbox-label {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    cursor: pointer;
  }
  
  input[type="checkbox"] {
    width: 18px;
    height: 18px;
    cursor: pointer;
  }
  
  .optimize-btn {
    width: 100%;
    padding: 1rem 2rem;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 1.1rem;
    font-weight: 600;
    cursor: pointer;
    transition: transform 0.2s, box-shadow 0.2s;
  }
  
  .optimize-btn:hover:not(:disabled) {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(102, 126, 234, 0.4);
  }
  
  .optimize-btn:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
  
  .error-card {
    background: #fee;
    border-left: 4px solid #e55;
  }
  
  .error-card h3 {
    color: #c33;
    margin-top: 0;
  }
  
  .results-card {
    animation: slideIn 0.5s ease-out;
  }
  
  @keyframes slideIn {
    from {
      opacity: 0;
      transform: translateY(20px);
    }
    to {
      opacity: 1;
      transform: translateY(0);
    }
  }
  
  .metrics-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1rem;
    margin: 1.5rem 0;
  }
  
  .metric {
    background: #f8f9fa;
    padding: 1.5rem;
    border-radius: 8px;
    text-align: center;
  }
  
  .quantum-advantage {
    background: linear-gradient(135deg, #667eea15 0%, #764ba215 100%);
  }
  
  .metric-label {
    font-size: 0.9rem;
    color: #666;
    margin-bottom: 0.5rem;
  }
  
  .metric-value {
    font-size: 1.8rem;
    font-weight: 700;
    color: #333;
  }
  
  .allocations {
    margin-top: 1rem;
  }
  
  .allocation-row {
    display: grid;
    grid-template-columns: 80px 1fr 80px 120px;
    align-items: center;
    gap: 1rem;
    padding: 0.75rem 0;
    border-bottom: 1px solid #eee;
  }
  
  .allocation-row:last-child {
    border-bottom: none;
  }
  
  .allocation-ticker {
    font-weight: 600;
    color: #667eea;
  }
  
  .allocation-bar-container {
    background: #e0e0e0;
    height: 24px;
    border-radius: 12px;
    overflow: hidden;
  }
  
  .allocation-bar {
    height: 100%;
    background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
    transition: width 0.8s ease-out;
  }
  
  .allocation-weight {
    text-align: right;
    font-weight: 600;
  }
  
  .allocation-amount {
    text-align: right;
    color: #666;
  }
  
  .execution-info {
    margin-top: 2rem;
    padding-top: 1rem;
    border-top: 1px solid #eee;
    font-size: 0.9rem;
    color: #666;
  }
  
  .separator {
    margin: 0 0.5rem;
    color: #ccc;
  }
  
  footer {
    text-align: center;
    color: white;
    margin-top: 3rem;
    opacity: 0.8;
  }
</style>
