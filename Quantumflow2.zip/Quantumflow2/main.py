"""
QuantumFlow FastAPI Backend
The nervous system connecting quantum consciousness to the web
"""

from fastapi import FastAPI, HTTPException, Depends, Header
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Optional, Dict
import yfinance as yf
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import sys
import os

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from quantum_engine.qaoa_optimizer import QAOAPortfolioOptimizer, create_mock_data

# Initialize FastAPI app
app = FastAPI(
    title="QuantumFlow API",
    version="1.0.0",
    description="Quantum-enhanced portfolio optimization using 12-qubit QAOA"
)

# CORS middleware for frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, specify exact origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global quantum optimizer instance
quantum_optimizer = QAOAPortfolioOptimizer(n_qubits=12, n_layers=2, backend="simulator")

# Request/Response Models
class OptimizationRequest(BaseModel):
    """Request model for portfolio optimization"""
    assets: List[str] = Field(..., example=["AAPL", "GOOGL", "MSFT"], min_items=2, max_items=12)
    risk_tolerance: float = Field(..., ge=0.0, le=1.0, example=0.5)
    investment_amount: float = Field(..., gt=0, example=10000)
    use_real_data: bool = Field(default=True, description="Fetch real market data vs. mock data")
    lookback_days: int = Field(default=365, ge=30, le=1825, description="Historical data period")

class AllocationDetail(BaseModel):
    """Individual asset allocation"""
    ticker: str
    weight: float
    amount: float
    expected_return: float

class OptimizationResponse(BaseModel):
    """Response model for optimization results"""
    status: str
    execution_time_ms: int
    quantum_mode: str
    portfolio: Dict[str, Dict]
    metrics: Dict[str, float]
    allocations: List[AllocationDetail]
    quantum_advantage: Dict[str, float]

class HealthResponse(BaseModel):
    """Health check response"""
    status: str
    quantum_backend: str
    qubits: int
    layers: int
    timestamp: str

# API Endpoints

@app.get("/", response_model=Dict)
async def root():
    """Root endpoint with API information"""
    return {
        "service": "QuantumFlow",
        "version": "1.0.0",
        "description": "Quantum portfolio optimization API",
        "endpoints": {
            "health": "/health",
            "optimize": "/optimize",
            "docs": "/docs"
        }
    }

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint"""
    return HealthResponse(
        status="quantum_ready",
        quantum_backend=quantum_optimizer.backend,
        qubits=quantum_optimizer.n_qubits,
        layers=quantum_optimizer.n_layers,
        timestamp=datetime.utcnow().isoformat()
    )

@app.post("/optimize", response_model=OptimizationResponse)
async def optimize_portfolio(request: OptimizationRequest):
    """
    Quantum portfolio optimization endpoint
    
    This is where the magic happens - quantum superposition meets capital allocation.
    """
    try:
        print(f"\n🌌 Optimization request: {len(request.assets)} assets, "
              f"risk={request.risk_tolerance}, amount=${request.investment_amount}")
        
        # Fetch market data
        if request.use_real_data:
            try:
                returns_dict, cov_matrix = fetch_market_data(
                    request.assets, 
                    request.lookback_days
                )
            except Exception as e:
                print(f"⚠️  Real data fetch failed: {e}, using mock data")
                returns_dict, cov_matrix = create_mock_data(request.assets)
        else:
            returns_dict, cov_matrix = create_mock_data(request.assets)
        
        # Run quantum optimization
        result = quantum_optimizer.optimize(
            assets=request.assets,
            historical_returns=returns_dict,
            covariance_matrix=cov_matrix,
            risk_tolerance=request.risk_tolerance
        )
        
        # Calculate dollar allocations
        allocations = []
        for asset, weight in result.weights.items():
            allocations.append(AllocationDetail(
                ticker=asset,
                weight=weight,
                amount=weight * request.investment_amount,
                expected_return=returns_dict.get(asset, 0.0)
            ))
        
        # Compute quantum advantage
        advantage = quantum_optimizer.estimate_quantum_advantage(len(request.assets))
        
        return OptimizationResponse(
            status="success",
            execution_time_ms=result.execution_time_ms,
            quantum_mode=quantum_optimizer.backend,
            portfolio=result.to_dict(),
            metrics={
                "expected_return": result.expected_return,
                "risk_score": result.risk_score,
                "sharpe_ratio": result.sharpe_ratio,
                "quantum_advantage_score": result.quantum_advantage_score
            },
            allocations=allocations,
            quantum_advantage=advantage
        )
        
    except Exception as e:
        print(f"❌ Optimization error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Optimization failed: {str(e)}")

@app.get("/assets/validate")
async def validate_assets(tickers: str):
    """
    Validate asset tickers before optimization
    
    Args:
        tickers: Comma-separated list of tickers (e.g., "AAPL,GOOGL,MSFT")
    """
    try:
        ticker_list = [t.strip().upper() for t in tickers.split(",")]
        
        valid = []
        invalid = []
        
        for ticker in ticker_list:
            try:
                stock = yf.Ticker(ticker)
                info = stock.info
                if info and 'symbol' in info:
                    valid.append({
                        "ticker": ticker,
                        "name": info.get('longName', ticker),
                        "type": info.get('quoteType', 'Unknown')
                    })
                else:
                    invalid.append(ticker)
            except:
                invalid.append(ticker)
        
        return {
            "valid": valid,
            "invalid": invalid,
            "total": len(ticker_list),
            "valid_count": len(valid)
        }
    
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# Helper Functions

def fetch_market_data(assets: List[str], lookback_days: int = 365) -> tuple:
    """
    Fetch real market data from Yahoo Finance
    
    Returns:
        Tuple of (returns_dict, covariance_matrix)
    """
    print(f"📊 Fetching {lookback_days} days of market data for {len(assets)} assets...")
    
    end_date = datetime.now()
    start_date = end_date - timedelta(days=lookback_days)
    
    # Download historical data
    data = yf.download(
        assets, 
        start=start_date, 
        end=end_date, 
        progress=False
    )
    
    # Extract closing prices
    if len(assets) == 1:
        prices = data['Close'].to_frame()
        prices.columns = assets
    else:
        prices = data['Close']
    
    # Calculate returns
    returns = prices.pct_change().dropna()
    
    # Mean returns (annualized)
    mean_returns = returns.mean() * 252  # 252 trading days per year
    returns_dict = mean_returns.to_dict()
    
    # Covariance matrix (annualized)
    cov_matrix = returns.cov().values * 252
    
    print(f"✅ Market data fetched successfully")
    
    return returns_dict, cov_matrix


if __name__ == "__main__":
    import uvicorn
    
    print("\n🌌 QuantumFlow API Server")
    print("=" * 50)
    print("Starting on http://localhost:8000")
    print("Docs available at http://localhost:8000/docs")
    print("=" * 50 + "\n")
    
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")
