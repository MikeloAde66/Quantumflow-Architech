#!/bin/bash
################################################################################
# QuantumFlow Production Deployment Script
# One-command installation for Ubuntu 22.04+ VPS
#
# Usage: bash install.sh
################################################################################

set -euo pipefail

echo "🌌 QuantumFlow Production Installation"
echo "========================================"

# Configuration
DOMAIN="${DOMAIN:-quantumflow.app}"
APP_USER="quantumflow"
APP_DIR="/home/$APP_USER/quantumflow"
DB_NAME="quantumflow_prod"
DB_USER="qflow"

# Generate secure secrets
DB_PASSWORD=$(openssl rand -base64 32)
SECRET_KEY=$(openssl rand -hex 32)

# Color output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

log_info() {
    echo -e "${GREEN}✓${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}⚠${NC} $1"
}

log_error() {
    echo -e "${RED}✗${NC} $1"
}

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   log_error "This script must be run as root (use sudo)"
   exit 1
fi

# System update
log_info "Updating system packages..."
apt update && apt upgrade -y

# Install dependencies
log_info "Installing system dependencies..."
apt install -y \
    python3.11 \
    python3-pip \
    python3.11-venv \
    postgresql \
    postgresql-contrib \
    redis-server \
    nginx \
    certbot \
    python3-certbot-nginx \
    git \
    ufw

# Create application user
log_info "Creating application user..."
if ! id "$APP_USER" &>/dev/null; then
    useradd -m -s /bin/bash "$APP_USER"
fi

# Clone repository
log_info "Cloning QuantumFlow repository..."
cd /home/$APP_USER

if [ -d "$APP_DIR" ]; then
    log_warn "Directory exists, pulling latest changes..."
    cd "$APP_DIR"
    sudo -u "$APP_USER" git pull
else
    log_warn "Please provide Git repository URL (or press Enter to skip):"
    read -r GIT_URL
    if [ -n "$GIT_URL" ]; then
        sudo -u "$APP_USER" git clone "$GIT_URL" quantumflow
        cd "$APP_DIR"
    else
        log_warn "Skipping git clone - please upload code manually to $APP_DIR"
        mkdir -p "$APP_DIR"
        chown -R "$APP_USER:$APP_USER" "$APP_DIR"
    fi
fi

# Python virtual environment
log_info "Setting up Python environment..."
cd "$APP_DIR/backend"
sudo -u "$APP_USER" python3.11 -m venv venv
sudo -u "$APP_USER" venv/bin/pip install --upgrade pip
sudo -u "$APP_USER" venv/bin/pip install -r requirements.txt

# PostgreSQL setup
log_info "Configuring PostgreSQL database..."
sudo -u postgres psql <<EOF
DROP DATABASE IF EXISTS $DB_NAME;
DROP USER IF EXISTS $DB_USER;
CREATE DATABASE $DB_NAME;
CREATE USER $DB_USER WITH PASSWORD '$DB_PASSWORD';
GRANT ALL PRIVILEGES ON DATABASE $DB_NAME TO $DB_USER;
\q
EOF

# Redis configuration
log_info "Configuring Redis..."
systemctl enable redis-server
systemctl start redis-server

# Environment configuration
log_info "Creating production environment file..."
cat > "$APP_DIR/backend/.env.production" <<EOF
# QuantumFlow Production Environment
ENVIRONMENT=production
DATABASE_URL=postgresql://$DB_USER:$DB_PASSWORD@localhost/$DB_NAME
REDIS_URL=redis://localhost:6379
SECRET_KEY=$SECRET_KEY
QUANTUM_MODE=simulator

# Stripe (add your keys)
STRIPE_SECRET_KEY=sk_live_...
STRIPE_WEBHOOK_SECRET=whsec_...

# Optional: IBM Quantum
# IBM_QUANTUM_TOKEN=your_token_here
EOF

chown "$APP_USER:$APP_USER" "$APP_DIR/backend/.env.production"
chmod 600 "$APP_DIR/backend/.env.production"

# Systemd service
log_info "Creating systemd service..."
cat > /etc/systemd/system/quantumflow.service <<EOF
[Unit]
Description=QuantumFlow API Server
After=network.target postgresql.service redis-server.service

[Service]
Type=simple
User=$APP_USER
WorkingDirectory=$APP_DIR/backend
Environment="PATH=$APP_DIR/backend/venv/bin"
EnvironmentFile=$APP_DIR/backend/.env.production
ExecStart=$APP_DIR/backend/venv/bin/gunicorn app.main:app \\
    --workers 4 \\
    --worker-class uvicorn.workers.UvicornWorker \\
    --bind 127.0.0.1:8000 \\
    --access-logfile /var/log/quantumflow/access.log \\
    --error-logfile /var/log/quantumflow/error.log
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

# Create log directory
mkdir -p /var/log/quantumflow
chown "$APP_USER:$APP_USER" /var/log/quantumflow

# Enable and start service
systemctl daemon-reload
systemctl enable quantumflow
systemctl start quantumflow

# Nginx configuration
log_info "Configuring Nginx..."
cat > /etc/nginx/sites-available/quantumflow <<EOF
upstream quantumflow_api {
    server 127.0.0.1:8000;
}

server {
    listen 80;
    server_name $DOMAIN api.$DOMAIN;

    location / {
        proxy_pass http://quantumflow_api;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        
        # WebSocket support
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
    }
    
    # Rate limiting
    limit_req_zone \$binary_remote_addr zone=api:10m rate=10r/s;
    limit_req zone=api burst=20 nodelay;
}
EOF

ln -sf /etc/nginx/sites-available/quantumflow /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default

nginx -t && systemctl restart nginx

# Firewall configuration
log_info "Configuring firewall..."
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw --force enable

# SSL certificate
log_info "Requesting SSL certificate..."
log_warn "Enter your email for Let's Encrypt notifications:"
read -r ADMIN_EMAIL

if [ -n "$ADMIN_EMAIL" ]; then
    certbot --nginx -d "$DOMAIN" -d "api.$DOMAIN" \
        --non-interactive \
        --agree-tos \
        -m "$ADMIN_EMAIL"
fi

# Display credentials
log_info "Installation complete!"
echo ""
echo "========================================"
echo "🎉 QuantumFlow is now running!"
echo "========================================"
echo ""
echo "🔒 Database Credentials:"
echo "   Database: $DB_NAME"
echo "   User: $DB_USER"
echo "   Password: $DB_PASSWORD"
echo ""
echo "🔑 Secret Key: $SECRET_KEY"
echo ""
echo "🌐 Access URLs:"
echo "   API: https://$DOMAIN"
echo "   Health: https://$DOMAIN/health"
echo "   Docs: https://$DOMAIN/docs"
echo ""
echo "📊 Service Management:"
echo "   Status: sudo systemctl status quantumflow"
echo "   Restart: sudo systemctl restart quantumflow"
echo "   Logs: sudo journalctl -u quantumflow -f"
echo ""
echo "⚠️  IMPORTANT: Save these credentials securely!"
echo "========================================"

# Save credentials to file
cat > /root/quantumflow_credentials.txt <<EOF
QuantumFlow Installation Credentials
Generated: $(date)

Database:
- Name: $DB_NAME
- User: $DB_USER
- Password: $DB_PASSWORD

Application:
- Secret Key: $SECRET_KEY
- Domain: $DOMAIN

API Endpoints:
- Health: https://$DOMAIN/health
- Docs: https://$DOMAIN/docs
EOF

chmod 600 /root/quantumflow_credentials.txt
log_info "Credentials saved to /root/quantumflow_credentials.txt"
