#!/bin/bash
################################################################################
# QuantumFlow Development Quick Start
# Sets up local Mac development environment
################################################################################

set -e

echo "🌌 QuantumFlow Development Setup"
echo "================================="

# Check Python version
if ! command -v python3.11 &> /dev/null; then
    echo "❌ Python 3.11 not found. Please install:"
    echo "   brew install python@3.11"
    exit 1
fi

# Check Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js not found. Please install:"
    echo "   brew install node"
    exit 1
fi

echo "✅ Prerequisites found"

# Backend setup
echo ""
echo "📦 Setting up backend..."
cd backend

if [ ! -d "venv" ]; then
    python3.11 -m venv venv
    echo "✅ Virtual environment created"
fi

source venv/bin/activate
pip install -q --upgrade pip
pip install -q -r requirements.txt
echo "✅ Python dependencies installed"

# Test quantum engine
echo ""
echo "⚛️  Testing quantum engine..."
python quantum_engine/qaoa_optimizer.py
echo "✅ Quantum engine working"

# Frontend setup
echo ""
echo "📦 Setting up frontend..."
cd ../frontend

if [ ! -d "node_modules" ]; then
    npm install
    echo "✅ Node dependencies installed"
fi

# Instructions
echo ""
echo "================================="
echo "🎉 Setup complete!"
echo "================================="
echo ""
echo "To start developing:"
echo ""
echo "1. Backend API:"
echo "   cd backend"
echo "   source venv/bin/activate"
echo "   uvicorn app.main:app --reload"
echo ""
echo "2. Frontend (in new terminal):"
echo "   cd frontend"
echo "   npm run dev"
echo ""
echo "Then visit:"
echo "   Frontend: http://localhost:3000"
echo "   API Docs: http://localhost:8000/docs"
echo ""
